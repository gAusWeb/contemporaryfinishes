<?php

if (qode_layer_slider_installed()) {
	include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/layer-slider/layer-slider-config.php';
}