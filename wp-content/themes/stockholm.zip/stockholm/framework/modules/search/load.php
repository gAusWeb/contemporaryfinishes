<?php
include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/search/search-functions.php';