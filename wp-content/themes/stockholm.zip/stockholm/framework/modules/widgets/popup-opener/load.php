<?php
require_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/widgets/popup-opener/popup-opener.php';
require_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/widgets/popup-opener/functions.php';