<?php
//Get popup HTML
add_action('qode_before_page_header', 'qode_get_popup');