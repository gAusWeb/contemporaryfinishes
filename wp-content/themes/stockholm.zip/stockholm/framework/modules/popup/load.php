<?php
include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/popup/options-map/map.php';
include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/popup/popup-functions.php';
include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/popup/template-hooks.php';