<?php

if(qode_is_yith_wcqv_install()) {
	include_once QODE_FRAMEWORK_MODULES_ROOT_DIR . '/woocommerce/plugins/yith-quick-view/yith-quick-view-conf.php';
	include_once QODE_FRAMEWORK_MODULES_ROOT_DIR . '/woocommerce/plugins/yith-quick-view/yith-quick-view-functions.php';
	include_once QODE_FRAMEWORK_MODULES_ROOT_DIR . '/woocommerce/plugins/yith-quick-view/yith-quick-view-hooks.php';
}