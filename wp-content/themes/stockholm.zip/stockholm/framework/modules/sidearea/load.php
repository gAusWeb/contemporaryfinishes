<?php

include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/sidearea/sidearea-functions.php';
