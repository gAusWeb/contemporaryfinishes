<?php

/*
  Interface: iIconCollection
  A interface that implements Icon Collection methods
 */

interface iIconCollection {

	public function getIconsArray();
}