<?php

include_once QODE_SHORTCODES_ROOT_DIR.'/google-map/functions.php';
include_once QODE_SHORTCODES_ROOT_DIR.'/google-map/google-map.php';