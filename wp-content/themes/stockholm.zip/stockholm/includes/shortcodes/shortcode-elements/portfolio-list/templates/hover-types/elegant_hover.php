<div class="portfolio_shader"></div>
<div class="text_holder">
	<div class="text_holder_inner">
		<div class="text_holder_inner2">
			<?php
			echo qode_get_shortcode_template_part('templates/parts/title', 'portfolio-list', '', $params);
			echo qode_get_shortcode_template_part('templates/parts/subtitle', 'portfolio-list', '', $params);
			echo qode_get_shortcode_template_part('templates/parts/categories', 'portfolio-list', '', $params);
			?>
		</div>
	</div>
</div>


