<div class="text_holder">
	<?php
	echo qode_get_shortcode_template_part('templates/parts/title', 'portfolio-list', '', $params);
	?>
</div>


