<?php

include_once QODE_SHORTCODES_ROOT_DIR.'/centered-portfolio-carousel/functions.php';
include_once QODE_SHORTCODES_ROOT_DIR.'/centered-portfolio-carousel/centered-portfolio-carousel.php';