<?php

include_once QODE_SHORTCODES_ROOT_DIR.'/image-with-overlapping-info/functions.php';
include_once QODE_SHORTCODES_ROOT_DIR.'/image-with-overlapping-info/image-with-overlapping-info.php';