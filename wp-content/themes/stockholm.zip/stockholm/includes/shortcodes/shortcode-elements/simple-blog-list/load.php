<?php

include_once QODE_SHORTCODES_ROOT_DIR.'/simple-blog-list/functions.php';
include_once QODE_SHORTCODES_ROOT_DIR.'/simple-blog-list/simple-blog-list.php';