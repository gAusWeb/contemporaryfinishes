<div class="qode-content-slide">
    <div class="qode-content-slide-content-holder">
		<?php echo do_shortcode($content); ?>
    </div>
</div>