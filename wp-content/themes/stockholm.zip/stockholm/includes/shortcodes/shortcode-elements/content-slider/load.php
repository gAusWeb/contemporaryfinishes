<?php

require_once QODE_SHORTCODES_ROOT_DIR.'/content-slider/functions.php';
require_once QODE_SHORTCODES_ROOT_DIR.'/content-slider/content-slider.php';
require_once QODE_SHORTCODES_ROOT_DIR.'/content-slider/content-slide.php';