<?php

include_once QODE_SHORTCODES_ROOT_DIR.'/interactive-image/functions.php';
include_once QODE_SHORTCODES_ROOT_DIR.'/interactive-image/interactive-image.php';