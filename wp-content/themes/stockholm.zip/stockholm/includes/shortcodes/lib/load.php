<?php

include_once QODE_ROOT_DIR.'/includes/shortcodes/lib/shortcode-functions.php';